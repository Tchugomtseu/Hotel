function ajouter(nom) {
    var input = document.getElementById(nom);
    var value = parseFloat(input.value);
    if (isNaN(value)) {
        value = 0;
    }
    input.value = Math.max(0, value + 1);
}

function retirer(nom) {
    var input = document.getElementById(nom);
    var value = parseFloat(input.value);
    if (isNaN(value)) {
        value = 0;
    }
    input.value = Math.max(0, value - 1);
}


function yearold() {
    if (document.getElementById("enfant").value === "") {
        document.getElementById("enfant").value = 0;
    }

    var nb_enfant = parseInt(document.getElementById("enfant").value);

    var ageEnfantHTML = "<tr id='age-enfant-row'>";
    ageEnfantHTML += "<td colspan='2'>Âge des enfants :</td>";
    ageEnfantHTML += "<td id='age-enfant-inputs'>";

    if (nb_enfant > 0) {
        for (var i = 0; i < nb_enfant; i++) {
            ageEnfantHTML += "<input required type='number' name='age' min='0' max='17' placeholder='Âge enfant " + (i + 1) + "'><br>";
        }
    }
    ageEnfantHTML += "</td></tr>";
    
    document.getElementById("age-enfant-row").innerHTML = ageEnfantHTML;
}




function recherche(event) {
    event.preventDefault(); 

    var datDep = document.getElementById("dat-dep").value;
    var datArr = document.getElementById("dat-arr").value;
    var adulte = document.getElementById("adult").value;
    var enfant = document.getElementById("enfant").value;
    var chambre = document.getElementById("chambre").value;
    var professionnel = document.getElementById("voyage_pro").checked;

    var resultat = document.getElementById("resultat");
    resultat.innerHTML = ""; 

    var dateDepart = new Date(datDep);
    var dateArrivee = new Date(datArr);

    if (dateDepart >= dateArrivee) {
        resultat.innerHTML = "La date de départ doit être antérieure à la date d'arrivée.";
        resultat.classList.add("error");
    } else {
        resultat.innerHTML += "<h2>Résultat de la recherche</h2>";
        resultat.innerHTML += "<span>Nombre d'adultes : " + adulte + "</span>";
        resultat.innerHTML += "<span>Nombre d'enfants : " + enfant + "</span>";
        resultat.innerHTML += "<span>Nombre de chambres : " + chambre + "</span>";
        if (professionnel) {
            resultat.innerHTML += "<span> voyage pour le travail:   oui</span>";
        }
        else{
            resultat.innerHTML += "<span> voyage pour le travail:    non</span>";
        }
        resultat.classList.remove("error");
        resultat.classList.add("show-results");
    }
}



